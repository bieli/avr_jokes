/* written by marekm@linux.org.pl, hardly worth copyrighting :-) */

#ifndef __ERRNO_H_
#define __ERRNO_H_ 1

extern int errno;

#define ERANGE 100

#endif
