#ifndef __STDLIB_H_
#define	__STDLIB_H_ 1

#define __need_NULL
#define __need_size_t
#define __need_wchar_t
#include <stddef.h>

#ifndef __ptr_t
#define __ptr_t void *
#endif

typedef struct {
	int quot;
	int rem;
} div_t;

typedef struct {
	long quot;
	long rem;
} ldiv_t;

typedef int (*__compar_fn_t)(const void *, const void *);

#define	RAND_MAX 0x7FFFFFFF

extern inline void abort(void) __attribute__((noreturn));
extern inline void
abort(void)
{
	for (;;);
}

extern inline int abs(int __x) __attribute__((const));
extern inline int
abs(int __x)
{
	return (__x < 0) ? -__x : __x;
}

extern inline long labs(long __x) __attribute__((const));
extern inline long
labs(long __x)
{
	return (__x < 0) ? -__x : __x;
}

extern void *bsearch(const void *, const void *, size_t, size_t,
	int (*)(const void *, const void *));

extern div_t div(int, int) __attribute__((const));

extern ldiv_t ldiv(long, long) __attribute__((const));

extern void qsort(void *, size_t, size_t, __compar_fn_t);

extern long strtol(const char *, char **, int);

extern unsigned long strtoul(const char *, char **, int);

extern inline int atoi(const char *__p);
extern inline int
atoi(const char *__p)
{
	return (int) strtol(__p, (char **) 0, 10);
}

extern inline long atol(const char *);
extern inline long
atol(const char *__p)
{
	return strtol(__p, (char **) 0, 10);
}

/* implemented but not tested */
extern void *malloc(size_t);
extern void free(void *);
extern double strtod(const char *, char **);

/* non-standard (i.e. non-ANSI C) functions */
char *itoa(int value, char *string, int radix);
extern char *dtostre( double f, char * s, unsigned char ndig, unsigned char flags);

#if 0  /* not yet implemented */

extern int atexit(void (*)(void));
extern double atof(const char *);
extern void *calloc(size_t, size_t);
extern void exit(int) __attribute__((noreturn));
extern int rand(void);
extern void *realloc(void *, size_t);
extern void srand(unsigned int);

#endif

#endif /* !__STDLIB_H_ */
