#ifndef _INTERRUPT_H_
#define _INTERRUPT_H_

#include <io.h>

#define sei()  asm volatile ("sei" ::)
#define cli()  asm volatile ("cli" ::)

extern inline void enable_external_int (unsigned char ints)
{
#ifdef AVR_MEGA  
  outp (ints, EIMSK);
#else
  outp (ints, GIMSK);
#endif
}

extern inline void timer_enable_int (unsigned char ints)
{
  outp (ints, TIMSK);
}

#endif
