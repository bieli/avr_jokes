/*
   math.h - mathematical functions

   Author : Michael Stumpf
            Michael.Stumpf@t-online.de

   __attribute__((const)) added by marekm@linux.org.pl for functions
   that "do not examine any values except their arguments, and have
   no effects except the return value", for better optimization by gcc.
 */

#ifndef __MATH_H
#define __MATH_H

#define PI      3.141592653589793238462643
#define SQRT2   1.4142135623730950488016887

extern double cos(double) __attribute__((const));
extern double fabs(double) __attribute__((const));
/* fabs seems to be built in already
extern inline double fabs( double __x )
  { double res;
    __asm__ __volatile__ ("ANDI r25,0x7F \n\t"
		: "=r" (res) : "0" (__x) );
    return res;
  }
*/
extern double fmod(double, double) __attribute__((const));
extern double modf(double, double *);
extern double sin(double) __attribute__((const));
extern double sqrt(double) __attribute__((const));
extern double tan(double) __attribute__((const));
extern double floor(double) __attribute__((const));
extern double ceil(double) __attribute__((const));
extern double frexp(double, int *);
extern double ldexp(double,int) __attribute__((const));
extern double exp(double) __attribute__((const));
extern double cosh(double) __attribute__((const));
extern double sinh(double) __attribute__((const));
extern double tanh(double) __attribute__((const));
extern double acos (double) __attribute__((const));
extern double asin (double) __attribute__((const));
extern double atan (double) __attribute__((const));	/* dummy function  */
extern double log (double) __attribute__((const));
extern double log10 (double) __attribute__((const));
extern double pow (double, double) __attribute__((const));
extern double strtod(const char *s, char **endptr) __attribute__((const));

/* non-standard functions */
extern double square(double) __attribute__((const));
extern double inverse(double) __attribute__((const));

/* not yet implemented :: double atan2(double,double); */

#endif /* _MATH_H */

