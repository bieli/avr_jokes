// i2cprogc.h

void see_write(             // move SRAM bytes into SEEPROM (write)
    char *sramaddr,          // starting SRAM address
    unsigned short seeaddr,  // starting address in SEEPROM (bit 15 ignored)
    unsigned char len);      // no. bytes to write (64 bytes max.)

void see_read(              // move SEEPROM bytes into SRAM (read)
    char *sramaddr,          // starting SRAM address
    unsigned short seeaddr,  // starting address in SEEPROM (bit 15 ignored)
    unsigned char len);      // no. bytes to move (255 bytes max.)

void see_wait(void);        // wait for SEEPROM not busy

#define _s2see(e, s, n)  see_wait(),see_write(s, e, n)
#define _see2s(s, e, n)  see_wait(),see_read(s, e, n)
