/*
   Copyright (C) 1999 Marek Michalkiewicz <marekm@linux.org.pl>

   Permission to use, copy, modify, and distribute this software and
   its documentation for any purpose and without fee is hereby granted,
   without any conditions or restrictions.  This software is provided
   "as is" without express or implied warranty.
 */

#ifndef _CRT1INIT_H_
#define _CRT1INIT_H_

/* Macros to define various crt1.s settings before main() is called.
   These macros should be called from within any of your C functions
   that is linked in, such as main().  They don't cause any code to
   be generated - they only change the default values of global
   virtual symbols used by crt1.s.  */

#define asm_def_ext_virt(name, val)		\
	asm volatile (	"#define extern virtual " name " %0\n"	\
			: /* no outputs */ : "i" (val))

/* Initial value for the WDTCR register.  This can be used to
   enable the watchdog timer as soon as possible after RESET -
   highly recommended for production use.  Default: 0.
   Example (enable WDT with maximum timeout):
	crt1_init_wdtcr(BV(WDE) | BV(WDP2) | BV(WDP1) | BV(WDP0));
 */
#define crt1_init_wdtcr(val) asm_def_ext_virt("CRT1_INIT_WDTCR", val)

/* Initial value for the MCUCR register.  If your hardware design
   includes external SRAM or memory-mapped devices, this should be
   used to enable the external SRAM interface.  Default: 0.
   Example (enable external SRAM with one wait state):
	crt1_init_mcucr(BV(SRE) | BV(SRW));
 */
#define crt1_init_mcucr(val) asm_def_ext_virt("CRT1_INIT_MCUCR", val)

/* Initial value for the stack pointer (SPH:SPL).  Currently this
   has no effect, as gcc sets up the stack pointer again in main(),
   so the gcc -minit-stack=... option should be used instead.
   Default: (internal SRAM size - 1) of the device specified.
   Example (set SP to point at the end of 32K external SRAM):
	crt1_init_stack(0x7FFF);
 */
#define crt1_init_stack(val) asm_def_ext_virt("CRT1_INIT_SP", val)

#endif
