/*
  io.h	
  General I/O Declarations, avr-gcc (c) 1999
  
  You can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2, or (at your option)
  any later version.
*/

#ifndef _IO_H_
#define _IO_H_

#define outb outp

#include <io-avr.h>
#include <iomacros.h>

#endif /* _IO_H_ */
