#ifndef __SETJMP_H_
#define __SETJMP_H_

/*
   jmp_buf:
	offset	size	description
	 0	16	call-saved registers (r2-r17)
	16	 2	frame pointer (r29:r28)
	18	 2	stack pointer (SPH:SPL)
	20	 1	status register (SREG)
	21	 3	return address (PC) (2 bytes used for <=128K flash)
	24 = total size
 */

typedef struct {
	/* call-saved registers */
	unsigned char j_r2;
	unsigned char j_r3;
	unsigned char j_r4;
	unsigned char j_r5;
	unsigned char j_r6;
	unsigned char j_r7;
	unsigned char j_r8;
	unsigned char j_r9;
	unsigned char j_r10;
	unsigned char j_r11;
	unsigned char j_r12;
	unsigned char j_r13;
	unsigned char j_r14;
	unsigned char j_r15;
	unsigned char j_r16;
	unsigned char j_r17;
	/* frame pointer, stack pointer, status register, program counter */
	unsigned int j_fp;  /* Y */
	unsigned int j_sp;
	unsigned char j_sreg;
	unsigned int j_pc;
	unsigned char j_pch;  /* only devices with >128K bytes of flash */
} jmp_buf[1];

extern int setjmp(jmp_buf __jmpb);
extern void longjmp(jmp_buf __jmpb, int __ret) __attribute__((noreturn));

#endif  /* !__SETJMP_H_ */
