/*            - io2323.h -

   This file #defines the internal register addresses for AT90S2323.

   Version: 1.20
*/


#ifndef __IO2323
#define __IO2323


/*==========================*/
/* Predefined SFR Addresses */
/*==========================*/

/* Input Pins, Port B */
#define PINB      0x16 

/* Data Direction Register, Port B */
#define DDRB      0x17 

/* Data Register, Port B */
#define PORTB      0x18 

/* EEPROM Control Register */
#define EECR      0x1C 

/* EEPROM Data Register */
#define EEDR      0x1D 

/* EEPROM Address Register Low */
#define EEARL     0x1E           
#define EEAR      0x1E 

/* Watchdog Timer Control Register */
#define WDTCR      0x21 

/* Timer/Counter 0 */
#define TCNT0      0x32 

/* Timer/Counter 0 Control Register */
#define TCCR0      0x33 

/* MCU Status Register */
#define MCUSR      0x34 

/* MCU general Control Register */
#define MCUCR      0x35 

/* Timer/Counter Interrupt Flag register */
#define TIFR      0x38 

/* Timer/Counter Interrupt MaSK register */
#define TIMSK      0x39 

/* General Interrupt Flag register */
#define GIFR      0x3A 

/* General Interrupt MaSK register */
#define GIMSK      0x3B 

/* Stack Pointer */
#define SP       0x3D 
#define SPL      0x3D 

/* Status REGister */
#define SREG     0x3F 


/*==============================*/
/* Interrupt Vector Definitions */
/*==============================*/

/* NB! vectors are specified as byte addresses */

#define    RESET_vect           (0x00)
#define    INT0_vect            (0x02)
#define    TIMER0_OVF_vect     (0x04)
   
 
/*
   The Register Bit names are represented by their bit number (0-7).
*/     
 
/* General Interrupt MaSK register */ 
#define    INT0    6
#define    INTF0   6
 
/* General Interrupt Flag Register */                 
#define    TOIE0   1
#define    TOV0    1
 
/* MCU general Control Register */ 
#define    SE      5
#define    SM      4
#define    ISC01   1
#define    ISC00   0
 
/* Timer/Counter 0 Control Register */
#define    CS02    2
#define    CS01    1
#define    CS00    0
                        
/* Watchdog Timer Control Register */
#define    WDTOE   4
#define    WDE     3
#define    WDP2    2
#define    WDP1    1
#define    WDP0    0
 
/* EEPROM Control Register */
#define    EEMWE   2
#define    EEWE    1
#define    EERE    0
 
/* Data Register, Port B */
#define    PB4     4
#define    PB3     3
#define    PB2     2
#define    PB1     1
#define    PB0     0
 
/* Data Direction Register, Port B */
#define    DDB4    4
#define    DDB3    3
#define    DDB2    2
#define    DDB1    1
#define    DDB0    0
 
/* Input Pins, Port B */
#define    PINB4   4
#define    PINB3   3
#define    PINB2   2
#define    PINB1   1
#define    PINB0   0
       
/* Pointer definition   */  
#define    XL     R26
#define    XH     R27
#define    YL     R28
#define    YH     R29
#define    ZL     R30
#define    ZH     R31
       
/* Constants */ 
#define    RAMEND    0xDF     
#define    XRAMEND   0xDF
#define    E2END     0x7F
#define    FLASHEND  0x07FF

#endif

