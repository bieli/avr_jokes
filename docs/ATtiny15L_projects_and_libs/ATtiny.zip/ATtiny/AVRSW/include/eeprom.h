/*
   Copyright (C) 1999 Marek Michalkiewicz <marekm@linux.org.pl>

   Permission to use, copy, modify, and distribute this software and
   its documentation for any purpose and without fee is hereby granted,
   without any conditions or restrictions.  This software is provided
   "as is" without express or implied warranty.
 */

#ifndef _EEPROM_H_
#define _EEPROM_H_

#define __need_size_t
#include <stddef.h>

#include <io.h>

/* return 1 if EEPROM is ready for a new read/write operation, 0 if not */
#define eeprom_is_ready() bit_is_clear(EECR, EEWE)

/* read one byte from EEPROM address ADDR */
extern unsigned char eeprom_rb(unsigned int addr);

/* read one 16-bit word (little endian) from EEPROM address ADDR */
extern unsigned int eeprom_rw(unsigned int addr);

/* write a byte VAL to EEPROM address ADDR */
extern void eeprom_wb(unsigned int addr, unsigned char val);

/* read a block of SIZE bytes from EEPROM address ADDR to BUF */
extern void eeprom_read_block(void *buf, unsigned int addr, size_t n);

#endif /* _EEPROM_H_ */
