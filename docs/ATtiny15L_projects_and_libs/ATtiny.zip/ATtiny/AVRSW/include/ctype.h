/*
   ctype.h - character conversion macros and ctype macros

  Author : Michael Stumpf
           Michael.Stumpf@t-online.de
*/

#ifndef __CTYPE_H_
#define __CTYPE_H_ 1

extern int isalnum(int __c) __attribute__((const));
extern int isalpha(int __c) __attribute__((const));
extern int isascii(int __c) __attribute__((const));
extern int iscntrl(int __c) __attribute__((const));
extern int isdigit(int __c) __attribute__((const));
extern int isgraph(int __c) __attribute__((const));
extern int islower(int __c) __attribute__((const));
extern int isprint(int __c) __attribute__((const));
extern int ispunct(int __c) __attribute__((const));
extern int isspace(int __c) __attribute__((const));
extern int isupper(int __c) __attribute__((const));
extern int isxdigit(int __c) __attribute__((const));
extern int toascii(int __c) __attribute__((const));
extern int tolower(int __c) __attribute__((const));
extern int toupper(int __c) __attribute__((const));

#endif
