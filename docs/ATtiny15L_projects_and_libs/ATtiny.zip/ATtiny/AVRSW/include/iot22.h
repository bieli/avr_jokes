#ifndef __IOT22
#define __IOT22

#include <avr/ATtiny22.inc>

#endif

