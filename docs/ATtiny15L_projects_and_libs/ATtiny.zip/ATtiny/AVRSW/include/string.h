/* 
   This file is part of the AVR C Library.
   Copyright (C) 1998, 1999 by Denis Chertykov (denisc@overta.ru)
   
   The AVR C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Library General Public License as
   published by the Free Software Foundation; either version 2 of the
   License, or (at your option) any later version.  */
/*
 *	ISO C Standard: 4.11 STRING HANDLING	<string.h>
 */

#ifndef	__STRING_H_
#define	__STRING_H_ 1

/* Get size_t and NULL from <stddef.h>.  */
#define	__need_size_t
#define	__need_NULL
#include <stddef.h>
#include <string-avr.h>

#endif /* string.h  */

