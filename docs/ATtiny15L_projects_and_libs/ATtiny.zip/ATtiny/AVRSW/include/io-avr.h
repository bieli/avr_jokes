#ifndef _IO_AVR_H_
#define _IO_AVR_H_

#ifdef AVR_AT90S2313
#  include <io2313.h>
#else
#ifdef AVR_AT90S2323
#  include <io2323.h>
#else
#ifdef AVR_AT90S2333
#  include <io2333.h>
#else
#ifdef AVR_AT90S2343
#  include <io2343.h>
#else
#ifdef AVR_ATtiny22
#  include <iotn22.h>
#else
#ifdef AVR_AT90S4414
#  include <io4414.h>
#else
#ifdef AVR_AT90S4433
#  include <io4433.h>
#else
#ifdef AVR_AT90S4434
#  include <io4434.h>
#else
#ifdef AVR_AT90S8515
#  include <io8515.h>
#else
#ifdef AVR_AT90C8534
#  include <io8534.h>
#else
#ifdef AVR_AT90S8535
#  include <io8535.h>
#else
#ifdef AVR_ATmega161
#  include <iom161.h>
#else
#ifdef AVR_ATmega603
#  include <iom603.h>
#else
#ifdef AVR_ATmega103
#  include <iom103.h>
#endif /*  AVR_ATmega103 */
#endif /*  AVR_ATmega603 */
#endif /*  AVR_ATmega161 */
#endif /*  AVR_AT90S8535 */
#endif /*  AVR_AT90C8534 */
#endif /*  AVR_AT90S8515 */
#endif /*  AVR_AT90S4434 */
#endif /*  AVR_AT90S4433 */
#endif /*  AVR_AT90S4414 */
#endif /*  AVR_ATtiny22 */
#endif /*  AVR_AT90S2343 */
#endif /*  AVR_AT90S2333 */
#endif /*  AVR_AT90S2323 */
#endif /*  AVR_AT90S2313 */

#endif /* _IO_AVR_H_ */
