/*
   Copyright (C) 1999 Marek Michalkiewicz <marekm@linux.org.pl>

   Permission to use, copy, modify, and distribute this software and
   its documentation for any purpose and without fee is hereby granted,
   without any conditions or restrictions.  This software is provided
   "as is" without express or implied warranty.
 */

#ifndef _WDT_H_
#define _WDT_H_

#include <io.h>

#define wdt_reset() asm volatile ("wdr")

#define wdt_enable(timeout)				\
	asm volatile (					\
		"in __tmp_reg__, __SREG__" "\n\t"	\
		"cli" "\n\t"				\
		"wdr" "\n\t"				\
		"out %1, %0" "\n\t"			\
		"out __SREG__, __tmp_reg__" "\n\t"	\
		: /* no outputs */			\
		: "r" ((uint8_t)((timeout) | BV(WDE))),	\
		  "I" (WDTCR)				\
	)

#define wdt_disable()					\
	asm volatile (					\
		"in __tmp_reg__, __SREG__" "\n\t"	\
		"cli" "\n\t"				\
		"wdr" "\n\t"				\
		"out %1, %0" "\n\t"			\
		"out %1, __zero_reg__" "\n\t"		\
		"out __SREG__, __tmp_reg__"		\
		: /* no outputs */			\
		: "r" (BV(WDTOE) | BV(WDE)),		\
		  "I" (WDTCR)				\
	)

#endif
