#############################################################################
#
#  Copyright (c) 2002-2006 Bruce D. Lightner (lightner@lightner.net)
#
#  You may distribute and\or use for any purpose modified or unmodified
#  copies of this software if you preserve the copyright notice above.
#
#  THIS SOFTWARE IS PROVIDED AS IS AND COME WITH NO WARRANTY OF ANY KIND,
#  EITHER EXPRESSED OR IMPLIED.  IN NO EVENT WILL THE COPYRIGHT HOLDER
#  BE LIABLE FOR ANY DAMAGES RESULTING FROM THE USE OF THIS SOFTWARE.
#
#############################################################################

Unzip the archive as follows to create a new Windows directory c:\ATtiny
and do a "test" make...

   c:
   cd \
   unzip ATtiny.zip
   set PATH=c:\ATtiny\AVRSW\bin;%PATH%
   cd \ATtiny\projects
   make clean
   make wdtest

Please read the file "projects/README.txt".

The subdirectories are as follows:

   projects       - sample ATtiny15L project (see Makefile)
   AVRSW\bin      - executables needed to make this work
   AVRSW\include  - include files
   AVRSW\lib      - gcc 2.95 libraries

You will likely need to modify the "make load" logic in "project/Makefile"
to use your favorite AVR program loader.

You may direct questions to Bruce D. Lightner (lightner@lightner.net)
