// uart.c

#include "uart.h"

void uart_reset(void)
{
    _uart_reset();   // setup for transmit
}
