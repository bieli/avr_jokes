// timer.c

#include "timer.h"

void timer0_init(void)
{
}

