// putchar.h

void putchar(unsigned char ch);
