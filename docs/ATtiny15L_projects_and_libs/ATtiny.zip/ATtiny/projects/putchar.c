// putchar.c

#include "uart.h"

void putchar(unsigned char ch)
{
    _putchar(ch);
}
