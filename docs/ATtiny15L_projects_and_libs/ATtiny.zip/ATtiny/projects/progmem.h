// progmem.h

#ifndef __PROGMEM_H
#define __PROGMEM_H

#define PROGMEM __attribute__ ((progmem))
#define LPM(addr) ({           \
        unsigned char t;                \
        asm volatile (         \
                "lpm" "\n\t"   \
                "mov    %0,r0" \
                : "=r" (t)     \
                : "z" (addr)   \
        );                     \
        t;                     \
})

#if 0
#define LPMR(addr, offset) ({           \
        unsigned char t;                \
        asm volatile (         \
                "add r30,%2" "\n\t"   \
                "adc r31,__zero_reg__" "\n\t"   \
                "lpm" "\n\t"   \
                "mov %0,r0" \
                : "=r" (t)     \
                : "z" (addr),  \
                  "r" (offset) \
                : "r30", "r31" \
        );                     \
        t;                     \
})
#else
#define LPMR(addr, offset) ({           \
        unsigned char t;                \
        asm volatile (         \
                "add r30,%A2" "\n\t"   \
                "adc r31,%B2" "\n\t"   \
                "lpm" "\n\t"   \
                "mov %0,r0" \
                : "=r" (t)     \
                : "z" (addr),  \
                  "r" ((uint16_t)(offset)) \
                : "r30", "r31" \
        );                     \
        t;                     \
})
#endif

#endif /* __PROGMEM_H */
