// rand.h

unsigned short rand(unsigned short seed);
