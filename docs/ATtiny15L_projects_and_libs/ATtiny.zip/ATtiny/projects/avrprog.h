// avrprog.h

#define CLOCK 1600000    /* clock rate of microcontroller (in Hz) */
#define VCC_MV 5000      /* processor voltage (millivolts) */

#define BAUD_RATE 38400  /* software UART baud rate */
//#define BAUD_RATE 57600
//#define BAUD_RATE 115200  /* software UART baud rate */

#if BAUD_RATE > 38400
#define TX_FALL_DELAY    /* use software delay for half-duplex UART circuit */
#endif

#define LED_PORT PORTB
#define LED_BIT 1         /* OC1A output (PB1, pin 6) */

#define TX_PORT PORTB   /* UART Tx port */
#define TX_BIT 4        /* UART Tx bit (PB4, pin 2, TXRX) */

#define SPI_PORT PORTB
#define MISO_BIT    0   /* input, PB0/MOSI, header pin 7 */
#define MOSI_BIT    1   /* output, PB1/MISO, header pin 5 */
#define SCK_BIT     2   /* output, PB2/SCK, header pin 3 */
#define RESET_BIT   3   /* output, PB3, header pin 6, active low */

