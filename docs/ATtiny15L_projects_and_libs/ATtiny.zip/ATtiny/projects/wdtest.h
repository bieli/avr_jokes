// wdtest.h

#define CLOCK 1600000    /* clock rate of microcontroller (in Hz) */
#define VCC_MV 5000      /* processor voltage (millivolts) */

#define BAUD_RATE 38400

#define TX_PORT PORTB   /* UART Tx port */
#define TX_BIT 4        /* UART Tx bit (PB4, pin 2, TXRX) */

#define LED_PORT PORTB
#define LED_BIT 1         /* OC1A output (PB1, pin 6) */

