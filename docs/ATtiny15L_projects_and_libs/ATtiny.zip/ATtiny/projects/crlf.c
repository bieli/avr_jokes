// crlf.c

#include "uart.h"
#include "crlf.h"

void crlf(void)
{
    unsigned char n = 2;

    while (n--) {
        _putchar((n) ? '\n' : '\r');
    }
}
