// motor2.h

#define CLOCK 1600000    /* clock rate of microcontroller (in Hz) */
//#define VCC_MV 5000      /* processor voltage (millivolts) */
#define VCC_MV 3300      /* processor voltage (millivolts) */

#define LED_PORT PORTB
#define LED_BIT 1         /* OC1A output (PB1, pin 6) */

#define MOTOR_PORT PORTB  /* P-chan FET gate, output (PB4, pin 2) */
#define MOTOR_BIT 4
