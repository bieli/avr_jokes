// candle.h

#define CLOCK 1600000    /* clock rate of microcontroller (in Hz) */
#define VCC_MV 5000      /* processor voltage (millivolts) */
#define TX_FALL_DELAY    /* use software delay for half-duplex UART circuit */
#define BAUD_RATE 57600
//#define BAUD_RATE 38400  /* software UART baud rate */
//#define BAUD_RATE 115200  /* software UART baud rate */

#define LED_PORT PORTB
#define LED_BIT 1         /* OC1A output (PB1, pin 6) */

#define ADC_BIT 2  /* ADC2 input (PB3, pin 3) */
///#define ADC_BIT 3  /* ADC3 input (PB4, pin 2) */

#define TM_PORT PORTB   /* thermistor driver port */
#define TM_BIT 0        /* thermistor driver bit */

#define TX_PORT PORTB   /* UART Tx port */
#define TX_BIT 4        /* UART Tx bit (PB4, pin 2, TXRX) */
//#define TX_BIT 3        /* UART Tx bit (PB2, pin 3) */
//#define TX_BIT 2        /* UART Tx bit (PB2, pin 7, SCK) */
