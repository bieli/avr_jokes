#define PORTD 0x12

#if 0
//static inline void
#define write_byte( adr, data ) \
{ \
    asm volatile ("out %0, %1" : : "I" ((unsigned char)(adr)), "r" ((unsigned char)(data))); \
}
#else

static inline void
write_byte( unsigned char adr, unsigned char data )
{
    asm ("out %0, %1" : : "M" (adr), "r" (data));
}

#endif

void main(void)
{

  unsigned char i;
  
  for( i=0; i < 255;i++) { 
    write_byte( PORTD, i );
  }
}
