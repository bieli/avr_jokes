// uart_rx.c

#include "uart.h"

void uart_rx(void)
{
    _uart_rx();   // switch from TX to RX mode
}
