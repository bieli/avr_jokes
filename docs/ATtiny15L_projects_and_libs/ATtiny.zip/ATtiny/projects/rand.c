// rand.c

/*
   http://www.dontronics.com/psbpix/random.html
  ((H7 xor H6) xor (H4 xor L3)) | ((H/L) << 1) 
*/

unsigned short rand(unsigned short seed)
{
    unsigned char L = (unsigned char)seed;
    unsigned char H = (unsigned char)(seed >> 8);
    unsigned a, b;

#if 0
    a = ((H>>7)&1) ^ ((H>>6)&1);
    b = ((H>>4)&1) ^ ((L>>3)&1);
#else
    a = b = 0;
    if (((H&(1<<7)) && !(H&(1<<6))) || (!(H&(1<<7)) && (H&(1<<6)))) a = 1;
    if (((H&(1<<4)) && !(L&(3<<6))) || (!(H&(1<<4)) && (H&(1<<3)))) b = 1;
#endif
    if (L & 0x80) {
        H = (H << 1) | 1;
    } else {
        H = H << 1;
    }
    L = (L << 1) | (a ^ b);
    //printf("%d %d [%d,%d,%d]\n", H, L, a, b, (a ^ b));
    return (H << 8) | L;
}

#ifdef _MAIN_

#include <stdio.h>

main()
{
    int i;
    unsigned short seed = 0x5555;

    for (i = 0; i < 1000; ++i) {
        seed = rand(seed);
        //printf("%d %d\n", seed, seed & 0xff);
        printf("%d\n", seed & 0xff);
    }
}
#endif
