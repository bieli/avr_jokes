// pmputstr.c

#include "pmputstr.h"
#include "uart.h"

void pmputstr(unsigned char PROGMEM *s)
{
    _pmputstr(s);
}
