// getchar.h

unsigned char getchar(void);
