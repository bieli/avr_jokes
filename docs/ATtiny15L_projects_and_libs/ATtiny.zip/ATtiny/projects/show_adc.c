// show_adc.c

#include "timer.h"

void show_adc(unsigned char v)
{
    unsigned char i;

    for (i = 0; i < 8; ++i) {
        if (v & 0x80) {
            outb(255, OCR1A);
        } else {
            outb(32, OCR1A);
        }
        _delay_cs(40);
        outb(0, OCR1A);
        _delay_cs(10);
        v = v << 1;
    }
    _delay_cs(100);
}
