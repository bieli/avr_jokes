// utest.c
//
//  UART test
//

#include "iodefs.h"
#include "timer.h"
#include "uart.h"

#define LOOPBACK

#if 0
#define reverse(a) ({ \
           unsigned char ch; \
           asm volatile ( \
           "ror %1" "\n\t" \
           "rol %0" "\n\t" \
           "ror %1" "\n\t" \
           "rol %0" "\n\t" \
           "ror %1" "\n\t" \
           "rol %0" "\n\t" \
           "ror %1" "\n\t" \
           "rol %0" "\n\t" \
           "ror %1" "\n\t" \
           "rol %0" "\n\t" \
           "ror %1" "\n\t" \
           "rol %0" "\n\t" \
           "ror %1" "\n\t" \
           "rol %0" "\n\t" \
           "ror %1" "\n\t" \
           "rol %0" "\n\t" \
           "ror %1" "\n\t" /* restore input */ \
           : /* output */ "=r&" (ch) \
           : /* input */ "r" ((uint8_t)(a)) \
           ); \
           ch; \
   })

unsigned char test(unsigned char x)
{
    return reverse(x);
}
#endif

int main(void)
{
    osccal();   // calibrate internal processor clock

    delay_cs(50);   // delay a bit

    _uart_reset();   // enable UART output
    _uart_tx();
    crlf();

    //while (1) { delay_ms(1); putchar('5'); }  // 'scope loop

#ifndef LOOPBACK
    while (1) {
        unsigned char ix;

        delay_cs(50);
        putstr("\rhello world! ");
        putchar((++ix & 1) ? '=' : '-');
        //crlf();
    }
#else /* LOOPBACK */
    putstr("loop-back test...\r\n");
    while (1) {
        unsigned char ch;

        putchar('?');
        putchar(' ');
        uart_rx();
        ch = getchar();
        uart_tx();
        putchar(' ');
        puthexb(ch);
        crlf();
    }
#endif /* LOOPBACK */
}
