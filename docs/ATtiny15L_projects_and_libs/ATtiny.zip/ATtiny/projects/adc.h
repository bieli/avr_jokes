// adc.h

#ifndef __ADC_H
#define __ADC_H

#include "iodefs.h"

typedef enum {
  ADC_CK2           = 1,
  ADC_CK4           = 2,
  ADC_CK8           = 3,
  ADC_CK16          = 4,
  ADC_CK32          = 5,
  ADC_CK64          = 6,
  ADC_CK128         = 7
} adc_clk;

#define ADCL  0x04
#define ADCH  0x05

#define ADCSR 0x06
#define ADEN  7
#define ADSC  6
#define ADFR  5
#define ADC_ONCE  0
#define ADC_FREE  1
#define ADIF  4
#define ADIE  3
#define ADPS2 2
#define ADPS1 1
#define ADPS0 0

#define ADMUX 0x07
#define REFS1 7
#define REFS0 6
#define ADC_REF_VCC    0
#define ADC_REF_EXT    1
#define ADC_REF_INT    2
#define ADC_REF_INTCAP 3

#define ADLAR 5
#define ADC_RIGHT 0
#define ADC_LEFT  1

#define MUX2  2
#define MUX1  1
#define MUX0  0
#define ADC_MUX_ADC0       0
#define ADC_MUX_ADC1       1
#define ADC_MUX_ADC2       2
#define ADC_MUX_ADC3       3
#define ADC_MUX_ADC2X1     4
#define ADC_MUX_ADC2X20    5
#define ADC_MUX_ADC23X1    6
#define ADC_MUX_ADC23X20   7

static void inline adc_setup(
    unsigned char ref, 
    unsigned char left, 
    unsigned char mux, 
    unsigned char free, 
    adc_clk clk
) {
    outb((((ref)&3)<<REFS0)|(((left)?1:0)<<ADLAR)|(((mux)&7)<<MUX0), ADMUX);
    outb((1<<ADEN)|(((free)?1:0)<<ADFR)|(((clk)&7)<<ADPS0), ADCSR);
}

#define adc_enable() sbi(ADCSR, ADEN)

#define adc_disable() cbi(ADCSR, ADEN)

#define adc_start() sbi(ADCSR, ADSC)

#define adc_input() inp(ADCH)

#if 0
static unsigned short adc_inputw(void)
{
    unsigned char ch = inp(ADCL);

    return (ch | (inp(ADCH) << 8));
}
#endif

#define _inputw(port) ({ \
        uint16_t w;                     \
        asm volatile (                        \
                "in %A0,%1" "\n\t"            \
                "in %B0,%1+1"             \
                : "=r" (w)        \
                : "I" ((uint8_t)(port))      \
        );                                    \
        w;                                   \
})

#define adc_inputw() _inputw(ADCL)

#endif /* __ADC_H */
