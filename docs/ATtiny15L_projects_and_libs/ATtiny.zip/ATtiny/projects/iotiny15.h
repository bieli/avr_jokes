/*            - iotiny15.h -

   This file #defines the internal register addresses for ATtiny15L.

   Version: 1.00

*/

#ifndef __IOTINY15
#define __IOTINY15

/*==========================*/
/* Predefined SFR Addresses */
/*==========================*/

/* ADC Data register */
#define ADC       0x04
#define ADCL       0x04
#define ADCH       0x05

/* ADC Control and Status Register */
#define ADCSR     0x06

/* ADC MUX */
#define ADMUX     0x07

/* Analog Comparator Control and Status Register */
#define ACSR       0x08 

/* Input Pins, Port B */
#define PINB      0x16 

/* Data Direction Register, Port B */
#define DDRB      0x17 

/* Data Register, Port B */
#define PORTB     0x18 

/* EEPROM Control Register */
#define EECR      0x1C 

/* EEPROM Data Register */
#define EEDR      0x1D 

/* EEPROM Address Register */
#define EEAR      0x1E 
#define EEARL      0x1E 
#define EEARH      0x1F 

/* Watchdog Timer Control Register */
#define WDTCR      0x21 

/* T/C 1 Input Capture Register */
#define ICR1      0x24 
#define ICR1L      0x24 
#define ICR1H      0x25 

/* Special Function I/O register */
#define SFIOR     0x2C

/* Timer/Counter1 Output Compare Register B */
#define OCR1B      0x2D 
#define OCR1BL      0x2D 
#undef  OCR1BH

/* Timer/Counter1 Output Compare Register A */
#define OCR1A      0x2E 
#define OCR1AL      0x2E 
#undef  OCR1AH

/* Timer/Counter 1 */
#define TCNT1     0x2E
#define TCNT1      0x2E 
#define TCNT1L     0x2E 
#undef  TCNT1H

/* Oscillator Calibration Register */
#define OSCCAL 0x31

/* Timer/Counter 1 Control and Status Register */
#define TCCR1      0x30

/* Timer/Counter 1 Control Register */
#define TCCR1A     0x2F 

/* Timer/Counter 0 */
#define TCNT0      0x32 

/* Timer/Counter 0 Control Register */
#define TCCR0      0x33 

/* MCU general Status Register */
#define MCUSR      0x34 

/* MCU general Control Register */
#define MCUCR      0x35 

/* Timer/Counter Interrupt Flag register */
#define TIFR       0x38 

/* Timer/Counter Interrupt MaSK register */
#define TIMSK      0x39 

/* General Interrupt Flag Register */
#define GIFR       0x3A 

/* General Interrupt MaSK register */
#define GIMSK      0x3B 

/* Status REGister */
#define SREG       0x3F 


/*==============================*/
/* Interrupt Vector Definitions */
/*==============================*/

/* NB! vectors are specified as byte addresses */

#define    RESET_vect           (0x00)
#define    INT0_vect            (0x02)
#define    PINS_vect            (0x04)
#define    TIMER1_COMPA_vect    (0x06)
#define    TIMER1_OVF_vect      (0x08)
#define    TIMER0_OVF_vect      (0x0A)
#define    EE_RDY_vect          (0x0C)
#define    ANA_COMP_vect        (0x0E)
#define    ADC_vect             (0x10)

/*
   The Register Bit names are represented by their bit number (0-7).
*/  

/* General Interrupt MaSK register */ 
#define    INT0         6
#define    PCIE         5

/* General Interrupt Flag Register */
#define    INTF0        6
#define    PCIF         5

/* Timer/Counter Interrupt MaSK register */
#define    TOIE1        7
#define    OCIE1A       6
#define    TICIE1       3
#define    TOIE0        1

/* Timer/Counter Interrupt Flag register */
#define    TOV1         7
#define    OCF1A        6
#define    ICF1         3
#define    TOV0         1

/* MCU general Status Register */
#define    WDRF         3
#define    BORF         2
#define    EXTRF        1
#define    PORF         0

/* MCU general Control Register */   
#define    PUD          6
#define    SE           5
#define    SM1          4
#define    SM0          3
#define    ISC01        1
#define    ISC00        0

/* Timer/Counter 0 Control Register */
#define    CS02         2
#define    CS01         1
#define    CS00         0 

/* Timer/Counter 1 Control Register */
#define    CTC1         7
#define    PWM1         6
#define    COM1A1       5
#define    COM1A0       4
#define    CS13         3
#define    CS12         2
#define    CS11         1
#define    CS10         0

/* Special Function I/O register */
#define    FOC1A        2
#define    PSR1         1
#define    PSR0         0

/* Watchdog Timer Control Register */  
#define    WDTOE        4
#define    WDE          3
#define    WDP2         2
#define    WDP1         1
#define    WDP0         0

/* EEPROM Control Register */
#define    EERIE        3
#define    EEMWE        2
#define    EEWE         1
#define    EERE         0

/* Data Register, Port B */  
#define    PB4          4
#define    PB3          3
#define    PB2          2
#define    PB1          1
#define    PB0          0

/* Data Direction Register, Port B */
#define    DDB5         5
#define    DDB4         4
#define    DDB3         3
#define    DDB2         2
#define    DDB1         1
#define    DDB0         0

/* Input Pins, Port B */
#define    PINB5        5
#define    PINB4        4
#define    PINB3        3
#define    PINB2        2
#define    PINB1        1
#define    PINB0        0

/* Analog Comparator Control and Status Register */
#define    ACD          7
#define    ACBG         6
#define    ACO          5
#define    ACI          4
#define    ACIE         3
#define    ACIS1        1
#define    ACIS0        0

/* ADC MUX */
#define    REFS1        7
#define    REFS0        6
#define    ADLAR        5
#define    MUX2         2
#define    MUX1         1
#define    MUX0         0

/* ADC Control and Status Register */
#define    ADEN         7
#define    ADSC         6
#define    ADFR         5
#define    ADIF         4
#define    ADIE         3
#define    ADPS2        2
#define    ADPS1        1
#define    ADPS0        0

/* Pointer definition   */
#define    XL           r26
#define    XH           r27
#define    YL           r28
#define    YH           r29
#define    ZL           r30
#define    ZH           r31

/* Constants        */ 
#define    RAMEND       0x000    /*Last On-Chip SRAM Location*/
#define    XRAMEND      0xFFFF
#define    E2END        0x3F
#define    FLASHEND     0x3FF

#endif /* __IOTINY15 */
