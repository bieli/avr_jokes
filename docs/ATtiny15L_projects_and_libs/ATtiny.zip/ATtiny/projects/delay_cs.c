// delay_cs.c

#include "timer.h"

void delay_cs(unsigned char msecs)
{
    _delay_cs(msecs);
}
