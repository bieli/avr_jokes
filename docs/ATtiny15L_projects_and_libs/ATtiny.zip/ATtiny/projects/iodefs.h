// iodefs.h

#ifndef __IODEFS_H
#define __IODEFS_H

#define outb outp
#include <iomacros.h>
#include "iotiny15.h"

#include "_io.h"

#ifndef CLOCK
#error Please #define CLOCK [processor clock rate (MHz)]
#endif

#ifndef VCC_MV
#error Please #define VCC_MV [processor voltage (mV)]
#endif

//-------------------------------------------------------------------------

int main(void) __attribute__ ((naked,noreturn));

#define DDR(port) (port-1)
#define PINS(port) (port-2)
#define PORT(port) (port)

#ifndef OSCCAL
// program memory location of the internal oscillator "calibration byte"
#define OSCCAL 1024  /* default to last byte of program memory */
#endif

#define _osccal(addr)                                \
        asm volatile (                               \
                "lpm" "\n\t"                         \
                "out 0x31,r0" /* OSCCAL register */  \
                : /* no outputs */                   \
                : "z" ((uint16_t)(addr))             \
                : "r0" /* clobbers */                \
        )
#define osccal() _osccal(OSCCAL) /* calibrate internal RC oscillator */

#define nop  asm volatile ("nop" ::)
#define sleep()  asm volatile ("sleep" ::)

#if 1
#define swap(a) ({ \
        unsigned char ch; \
        asm volatile ( \
        "swap %0"\
        : "=r" (ch) \
        : "0" ((uint8_t)(a)) \
        ); \
        ch; \
})
#else
#define swap(a) ({ \
        unsigned char ch; \
        asm volatile ( \
        "mov %0, %1" "\n\t" \
        "swap %0"\
        : "=r&" (ch) \
        : "r" ((uint8_t)(a)) \
        ); \
        ch; \
})
#endif

#if 1
#define hi(w) ({ \
        unsigned char ch; \
        asm volatile ( \
        "mov %0, %B1" "\n\t" \
        : "=r" (ch) \
        : "r" ((uint16_t)(w)) \
        ); \
        ch; \
})
#else
#define hi(w) ({ \
        unsigned char ch; \
        asm volatile ( \
        "mov %0, %B1" "\n\t" \
        : "=r&" (ch) \
        : "r" ((uint16_t)(w)) \
        ); \
        ch; \
})
#endif

#define _BYTE(ch) ({                      \
        uint8_t t;                        \
        asm volatile (                    \
                "ldi %0, %1"              \
                : "=d" (t)                \
                : "M" ((uint8_t)(ch))     \
        );                                \
        t;                                \
 })

#define BYTE(ch) _BYTE(ch)

//-------------------------------------------------------------------------

#define read_mcusr() ({                   \
        uint8_t t;                        \
        asm volatile (                    \
                "in %0,0x34" "\n\t"       \
                "out 0x34,r1"             \
                : "=r" (t)                \
                : /* no inputs */         \
        );                                \
        t;                                \
 })

//-------------------------------------------------------------------------

#ifndef TX_PORT
#define TX_PORT PORTB   /* UART Tx port */
#endif

#ifndef TX_BIT
#define TX_BIT 2        /* UART Tx bit (PB2, pin 7, SCK) */
#endif

#endif /* !__IODEFS_H */
