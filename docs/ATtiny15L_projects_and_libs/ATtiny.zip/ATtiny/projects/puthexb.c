// puthexb.c

#include "uart.h"

void puthexb2(unsigned char val, char ch2)
{
    _puthexb2(val, ch2);
}
