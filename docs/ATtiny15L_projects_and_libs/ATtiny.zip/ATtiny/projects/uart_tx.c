// uart_tx.c

#include "uart.h"

void uart_tx(void)
{
    _uart_tx();   // switch from RX to TX mode
}
