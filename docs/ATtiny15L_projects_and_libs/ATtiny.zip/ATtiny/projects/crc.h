// crc.h
//
// X.25 HDLC FCS CRC (RFC 1171)
//

#define INITFCS 0xffff  /* initial FCS value */
#define GOODFCS 0xf0b8  /* good final FCS value */
#define HDLCPLY 0x8408  /* HDLC polynomial: x**0 + x**5 + x**12 + x**16 */

static __inline unsigned short calcFCS(unsigned char b)
{
    unsigned short v = b;
    unsigned char n = 8;

    while (n--) {
        v = v & 1 ? (v >> 1) ^ HDLCPLY : v >> 1;
    }
    return v;
}

//
// Sample routine usage:
//
//   bool CheckFCS(unsigned char *buf, int len)
//   {
//       unsigned short fcs = INITFCS;
//       while (len--)
//           fcs = (fcs >> 8) ^ calcFCS((unsigned char)(fcs ^ (*buf++)));
//       return (fcs == GOODFCS) ? true : false;
//   }

//
// Sample test buffer: 0x72, 0xd3, 0x4f, 0x0c, 0x3c (fcs = 0xf0b8)
//
