// pmputstr.h

#ifndef __PMPUTSTR_H
#define __PMPUTSTR_H

#include "uart.h"

#define PSTR(s) ({static char c[] PROGMEM = s;c;})
#define putstr(s) pmputstr(PSTR(s))

static void inline _pmputstr(unsigned char PROGMEM *s)
{
    unsigned char c ;

    while ((c = LPM(s)) != 0) {
        _putchar(c);
        s += _BYTE(1);
    }
}

static void inline _putstr(unsigned char PROGMEM *s)
{
    unsigned char c ;

    while ((c = LPM(s)) != 0) {
        putchar(c);
        s += _BYTE(1);
    }
}

void pmputstr(unsigned char PROGMEM *s);

#endif /* __PMPUTSTR_H */
