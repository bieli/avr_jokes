// puthexb.h

#ifndef __PUTHEXB_H
#define __PUTHEXB_H

#include "uart.h"

#define _puthexb(ch) _puthexb2(ch, 0)
#define puthexb(ch) puthexb2(ch, 0)

static void inline _puthexb2(unsigned char val, char ch2)
{
     unsigned char i = 3;
     unsigned char ch;

     while (i--) {
         if (i == 0) {
             if (ch2 == 0) break;
             ch = ch2;
         } else {
             ch = val >> 4;
             ch &= 0x0f;
             ch += '0';
             if (ch > '9') ch += ('a' - '9' - 1);
         }
         _putchar(ch);
         val = val << 4;
     }
}

void puthexb2(unsigned char val, char ch2);

#endif /* __PUTHEXB_H */
