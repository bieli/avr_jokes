// motor.c

#include "iodefs.h"
#include "timer.h"

#define MOTOR_PERIOD_SECS 60
#define MOTOR_PULSE_MSECS 200

/*********************************************************************

   20 msec @ 0.2 A every 60 seconds

   0.2 A * 0.200 sec / 60 sec = 0.2 / 300 = 667 uA avg.

   2000 mA-hr AA cells => 3,000 hr => 125 days => ~4 months

   2000 mA-hr AA cells @ 1 mA avg => 83 days
   2000 mA-hr AA cells @ 3 mA avg => 27 days

*********************************************************************/
//
// active low LED push-pull driver
//
#define led_on()  cbi(LED_PORT, LED_BIT)
#define led_off() sbi(LED_PORT, LED_BIT)
#define led_init() sbi(DDR(LED_PORT),LED_BIT); /* LED driver output */ \
                   led_off()

//
// motor with P-chan FET driver
//
#define motor_on()  cbi(MOTOR_PORT, MOTOR_BIT)
#define motor_off() sbi(MOTOR_PORT, MOTOR_BIT)
#define motor_init() sbi(DDR(MOTOR_PORT),MOTOR_BIT); /* motor driver output */ \
                     motor_off()

int main(void)
{
    unsigned char mcusr;
    register unsigned char ix asm("r2");  // don't initialize this!

    osccal();   // calibrate internal processor clock

    mcusr = read_mcusr();

    outb((1 << WDE) | WD_1024K, WDTCR);   // enable watchdog timer

    outb((SM_PWROFF << SM0), MCUCR);      // select power down sleep mode
    sbi(MCUCR, SE);                       // enable sleep mode

    timer1_stop();   // stop timer

    led_init();
    motor_init();

    if ((mcusr & (1 << WDRF)) == 0) {
        ix = 0;

        // pulse LED after reset
        led_on(); delay_cs(1); led_off();
        delay_cs(10);
        led_on(); delay_cs(1); led_off();
        delay_cs(10);
        led_on(); delay_cs(1); led_off();
        delay_cs(10);

        // pulse motor on startup if external reset
        if ((mcusr & (1 << EXTRF)) != 0) {
            led_on();
            motor_on();
            delay_cs(MOTOR_PULSE_MSECS/10);
            led_off();
            motor_off();
        }
    }

    while (1) {
        ++ix;
        if (ix >= SEC2WDCYC(MOTOR_PERIOD_SECS, WD_1024K)) {
            ix = 0;
            led_on();
            motor_on();
            delay_cs(MOTOR_PULSE_MSECS/10);
            led_off();
            motor_off();
        }
        sleep();
    }
}
