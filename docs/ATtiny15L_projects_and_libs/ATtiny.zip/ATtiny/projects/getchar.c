// getchar.c

#include "uart.h"

unsigned char getchar(void)
{
    return _getchar();
}
