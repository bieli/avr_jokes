// touch.h

#define CLOCK 1600000    /* clock rate of microcontroller (in Hz) */
#define VCC_MV 6000      /* processor voltage (millivolts) */

#define LAMP_PORT PORTB  /* P-chan FET gate, output (PB1, pin 6) */
#define LAMP_BIT 1       /* OC1A output (PB1, pin 6) */

#define PBSW_PORT PORTB  /* push-button switch to ground */
#define PBSW_BIT 3       /* input, needs pull-up, (PB3, pin 3) */
