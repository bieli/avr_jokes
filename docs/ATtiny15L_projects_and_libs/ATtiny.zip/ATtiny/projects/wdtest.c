// wdtest.c
//
//  Watchdog-based long-term timer test (ultra-low power)
//

#include "iodefs.h"
#include "timer.h"
#include "uart.h"

int main(void)
{
    unsigned char mcusr;
    register unsigned char ix asm("r2");  // don't initialize this!

    mcusr = read_mcusr();  // find why we are here?

    osccal();   // calibrate internal processor clock

    _uart_reset();   // enable UART output
    _uart_tx();

    if ((mcusr & (1 << WDRF)) == 0) ix = 0;  // reset if NOT watchdog restart

    cbi(LED_PORT,LED_BIT);       // LED on
    sbi(DDR(LED_PORT),LED_BIT);  // make LED driver output
    if ((mcusr & (1 << WDRF)) != 0) {
        delay_cs(1);
    } else {
        delay_cs(50);
    }
    sbi(LED_PORT,LED_BIT);       // LED off

    //outb((1 << SE) | SM_IDLE, MCUCR);   // enable sleep mode (idle mode)
    outb((1 << SE) | SM_PWROFF, MCUCR);   // enable sleep mode (power down)
    outb((1 << WDE) | WD_1024K, WDTCR);   // enable watchdog timer
    while (1) {
        ++ix;
        if (ix >= SEC2WDCYC(10, WD_1024K)) {
            ix = 0;
            cbi(LED_PORT,LED_BIT);       // LED on
            sbi(DDR(LED_PORT),LED_BIT);  // make LED driver output
            delay_cs(50);
            sbi(LED_PORT,LED_BIT);       // LED off
            putchar('.');
        }
        sleep();
    }
}
