// delay_ms.c

#include "timer.h"

void delay_ms(unsigned char msecs)
{
    _delay_ms(msecs);
}
