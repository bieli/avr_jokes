// show_adc.h

void show_adc(unsigned char v);
