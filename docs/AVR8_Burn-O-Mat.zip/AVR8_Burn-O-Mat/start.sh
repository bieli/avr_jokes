#!/bin/bash
java -jar AVR8_Burn_O_Mat.jar
