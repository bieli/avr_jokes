/*
    File:       gp2d120.c
    Version:    1.0.0
    Date:       May. 11, 2006
    
    GP2D120 Distance Measurement Routines.  
    
    ****************************************************************************
    Copyright (C) 2006 Micah Carrick   <email@micahcarrick.com>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    ****************************************************************************
*/

#include <stdlib.h>
#include <avr/io.h> 
#include <avr/pgmspace.h>
#include "gp2d120.h"

/* Returns a uint8_t value representing the cm to the object based on the 8-bit
 * ADC values passed to the function.  Uses the lookup table values defined in
 * gp2d120.h
*/
uint8_t
gp2d120_adc8_to_cm (uint8_t adc_value)
{
        return pgm_read_byte(&gp2d120_data[adc_value]);
} 
