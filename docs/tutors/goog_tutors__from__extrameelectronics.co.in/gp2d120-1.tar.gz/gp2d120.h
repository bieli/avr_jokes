/*
    File:       gp2d120.h
    Version:    1.0.0
    Date:       May. 11, 2006
    
    GP2D120 Distance Measurement Routines header file.  
    
    ****************************************************************************
    Copyright (C) 2006 Micah Carrick   <email@micahcarrick.com>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
    ****************************************************************************
*/

#ifndef GP2D120_H
#define GP2D120_H

#include <stdlib.h>
#include <avr/io.h> 
#include <avr/pgmspace.h>

/* Lookup table for 8-bit ADC to disctance in centimeters based on 
 * experimentation with AREF=3.3V.  See www.micahcarrick.com for more details.
*/
static uint8_t gp2d120_data[] PROGMEM = { 
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,30,30,29,28,
        27,26,25,25,24,24,24,23,23,23,22,22,21,20,20,19,19,19,19,18,18,18,17,17,
        17,16,16,16,15,15,15,15,15,14,14,14,13,13,13,13,13,13,12,12,12,12,12,12,
        11,11,11,11,11,11,10,10,10,10,10,10,10,9,9,9,9,9,9,9,9,9,8,8,8,8,8,8,8,
        8,8,8,8,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,
        6,6,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,
        4,4,4,4,4,4,4,4,4,4,4,4,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,2,2,2,
        2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2 
};

/* function prototypes */
uint8_t gp2d120_adc8_to_cm (uint8_t adc_value);

#endif  /* GP2D120_H */
