This is a hex file ready to burn in a ATmega16/ATmega32 MCU for testing of 24C EEPROM routines.

Copyright 2007-2009
Avinash Gupta
eXtremeElectronics.co.in