/*-----------------------------------------------------------------------------
 * File: MR-2313.C
 * Author: MICROROBOT Company - http://www.microrobot.com
 * Copyright (c) July, 2003
 * Description: Turns on and off all the ports.
 *
 * Resonator frequency = 8 MHz
 *---------------------------------------------------------------------------*/

#include <avr\io.h>

typedef unsigned char byte;
typedef unsigned int word;

#define sei()  asm volatile ("sei" ::)
#define cli()  asm volatile ("cli" ::)

// 1msec UNIT delay function
void delay_1ms(unsigned int i)
{
	word j;
	while(i--)
	{
		j=200;   // 8Mhz
		while(j--);
	}
}

void port_init(void)
{
//	outp( 0xff, DDRB );	//Configure PORTB as an output port.
//	outp( 0xff, DDRD );	//Configure PORTD as an output port.

//	outp( 0xff, PORTB );	//Output 0xff to PORTB.
//	outp( 0xff, PORTD );	//Output 0xff to PORTD.

	DDRB = 0xff;
	DDRD = 0xff;

	PORTB = 0xff;
	PORTD = 0xff;
}

void all_port_set(void)
{
//	outp( 0xff, PORTB );	//Output 0xff to PORTB.
//	outp( 0xff, PORTD );	//Output 0xff to PORTD.
	PORTB = 0xff;
	PORTD = 0xff;
}

void all_port_clear(void)
{
//	outp( 0, PORTB );	//Output 0 to PORTB.
//	outp( 0, PORTD );	//Output 0 to PORTD.
	PORTB = 0;
	PORTD = 0;
}

int main(void)
{
	port_init();			//Ports Initialization
	word j = 10000, i = 10000, a = 10000;
		
	while(1)
	{
/*
		a -= 100;
		
		i = a;

		all_port_clear();		
		
		while(i--)
		{
			j=2500;
			while(j--);
		}

		all_port_set();
		
		i = a;
		
		while(i--)
		{
			j=2500;
			while(j--);
		}
*/
		all_port_clear();		
		delay_1ms(500);
		all_port_set();
		delay_1ms(500);
	}
}

