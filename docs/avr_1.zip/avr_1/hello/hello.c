/*
* hello.c plik g�wny programu kursu EdW
* Cz�� pierwsza - pocz�tki
* 
* Autor: Rados�aw Koppel	kompilator: WinAVR20050214
*/
#include <avr\io.h>
#include <avr\delay.h>

int main(void)
{
	/* Ustawienie wyj�� */ 
	DDRD = 0xff; 
	
	for(;;)
	{
		/*wy��czenie diod*/
		PORTD = 0xff; 
		_delay_loop_2(0xffff); 
		/*w��czenie diod*/
		PORTD = 0; 
		_delay_loop_2(0xffff); 
	}
	return 0; 
}
