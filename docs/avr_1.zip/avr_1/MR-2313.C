/*-----------------------------------------------------------------------------
 * File: MR-2313.C
 * Author: MICROROBOT Company - http://www.microrobot.com
 * Copyright (c) July, 2003
 * Description: Turns on and off all the ports.
 *
 * Resonator frequency = 1 MHz
 *---------------------------------------------------------------------------*/

#include <io.h>

typedef unsigned char byte;
typedef unsigned int word;

#define sei()  asm volatile ("sei" ::)
#define cli()  asm volatile ("cli" ::)

// 1msec UNIT delay function
void delay_1ms(unsigned int i)
{
	word j;
	while(i--)
	{
		j=250;   // 1Mhz
		while(j--);
	}
}

void port_init(void)
{
	outp( 0xff, DDRB );	//Configure PORTB as an output port.
	outp( 0xff, DDRD );	//Configure PORTD as an output port.

	outp( 0xff, PORTB );	//Output 0xff to PORTB.
	outp( 0xff, PORTD );	//Output 0xff to PORTD.
}

void all_port_set(void)
{
	outp( 0xff, PORTB );	//Output 0xff to PORTB.
	outp( 0xff, PORTD );	//Output 0xff to PORTD.
}

void all_port_clear(void)
{
	outp( 0, PORTB );	//Output 0 to PORTB.
	outp( 0, PORTD );	//Output 0 to PORTD.
}

int main(void)
{
	port_init();			//Ports Initialization

	while(1)
	{
		all_port_set();
		delay_1ms(500);
		all_port_clear();
		delay_1ms(500);
	}
}

