#include <inttypes.h>
#include <avr/io.h>
//#include <avr/interrupt.h>
//#include <avr/sleep.h>

#include "iocompat.h"


#define KEY_LEFT 

void ioinit (void)
{

}

int main (void)
{
    ioinit ();

    for (;;)
    {
//        sleep_mode();
    }

    return (0);
}


