#ifndef _CONFIG_HPP_
#define _CONFIG_HPP_
#include "func.h"

// common typedefs

typedef unsigned long ulong;
typedef unsigned int uint;
typedef char *string;


//#define ARRAY_SIZE(x) (sizeof(x)/sizeof(x[0]))

// config data
//const uint maxStringLen = 64;

#endif /*_CONFIG_HPP_*/